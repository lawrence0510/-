package com.example.co2k_java_2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import com.squareup.picasso.Picasso;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {

        private List<Recipe1> recipe1s;
        private Context context;

        public MyAdapter(List<Recipe1> recipes, Context context) {
                this.recipe1s = recipe1s;
                this.context = context;
        }


        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
                View v = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.recipe_block, parent, false);
                return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position){

                Recipe1 recipe1 = recipe1s.get(position);
                holder.tv_name.setText(recipe1.getName());

                Picasso.get()
                        .load(recipe1.getUrl())
                        .into(holder.iv_recipe);
        }

        @Override
        public int getItemCount() {
                return recipe1s.size() ;
        }


        public class ViewHolder extends RecyclerView.ViewHolder {

                public TextView tv_name;
                public ImageView iv_recipe;

                public ViewHolder(View v) {
                        super(v);
                        tv_name = (TextView) v.findViewById(R.id.name);
                        iv_recipe = (ImageView) v.findViewById(R.id.recipe_img);
                }
        }

}
