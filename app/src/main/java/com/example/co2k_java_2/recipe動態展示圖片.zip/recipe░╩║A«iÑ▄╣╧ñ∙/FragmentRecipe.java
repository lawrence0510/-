package com.example.co2k_java_2;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import com.example.co2k_java_2.databinding.FragmentHomeBinding;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class FragmentRecipe extends Fragment {

//    private FragmentHomeBinding binding;
    protected Python py;
    protected Button bnt;
    protected TextView tv;
    protected ImageView iv;
    protected PyObject egStore, obj = null, func_1 = null, func_2 = null;
    protected BitmapDrawable drawable;
    protected Bitmap bitmap;
    protected String imageString = "", information, info[];
    protected ArrayList<Recipe1> recipe1s;
    protected Bitmap b = null;

    private GridView gvShow;


    public FragmentRecipe() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_recipe, container, false);

        if(!Python.isStarted())
            Python.start(new AndroidPlatform(getContext()));

        py = Python.getInstance();
//        final PyObject pyobj = py.getModule("test_py");
//        egStore = py.getModule("recipe1");
//        bnt = (Button)  view.findViewById(R.id.bnt_test);
//        tv = (TextView) view.findViewById(R.id.tv_test);
//        iv = (ImageView) view.findViewById(R.id.iv_test);

        obj = py.getModule("recipe1");

        func_1 = obj.callAttr("input_ingredients", "蛋");
        func_2 = obj.callAttr("get_recipes");

        information = func_2.toString();
        info = information.split(",");

        recipe1s = new ArrayList<>();

        for(int i = 0; i < info.length; ++i){

            if(i%3 == 2){
                Recipe1 recipe1 = new Recipe1(info[i -2], info[i - 1], info[i]);
                recipe1s.add(recipe1);
            }
        }

//        String[] name = new String[recipe1s.size()];
//        for(int i = 0; i < recipe1s.size(); ++i){
//            name[i] = recipe1s.get(i).getName();
//        }
//
//        String[] imgIds = new String[recipe1s.size() ];
//        for(int i = 0; i < recipe1s.size(); ++i){
//            imgIds[i] = recipe1s.get(i).getUrl();
//        }


//        List<Map<String, Object>> listitem = new ArrayList<>();
//        for(int i = 0; i < recipe1s.size(); ++i){
//            Map<String, Object> showitem = new HashMap<>();
//            showitem.put("name", recipe1s.get(i).getName());
//            showitem.put("recipe_img", recipe1s.get(i).getImage());
//            listitem.add(showitem);
//         }


        MyAdapter myAdapter = new MyAdapter(recipe1s, getContext());
//        SimpleAdapter myAdapter = new SimpleAdapter(getContext(), listitem, R.layout.recipe_block, new String[]{"name", "recipe_img"}, new int[]{R.id.name, R.id.recipe_img});
//        SimpleAdapter myAdapter = new SimpleAdapter(getContext(), listitem, R.layout.recipe_block, new String[]{"name"}, new int[]{R.id.name});
        RecyclerView view_1 = (RecyclerView) view.findViewById(R.id.rvShow);
//        view_1.setLayoutManager(new LinearLayoutManager(getContext()));
        view_1.setAdapter(myAdapter);



//        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(),android.R.layout.simple_list_item_1, name);
//        GridView list_test = (GridView) view.findViewById(R.id.gvShow);
//        list_test.setAdapter(adapter);







//        Glide.with(view).load("https://imageproxy.icook.network/resize?background=255%2C255%2C255&height=150&nocrop=false&stripmeta=true&type=auto&url=http%3A%2F%2Ftokyo-kitchen.icook.tw.s3.amazonaws.com%2Fuploads%2Frecipe%2Fcover%2F423917%2F1a6becf6fa3e903c.jpg&width=200").into(iv);

//        bnt.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {

//                drawable = (BitmapDrawable)iv.getDrawable();
//                bitmap = drawable.getBitmap();
//                imageString = getStringImage(bitmap);
//ㄋ
//                obj = pyobj.callAttr("main", imageString);
//                obj = pyobj.callAttr("main");




//
//
//
//                String s = "";
//                for(Recipe1 r : recipe1s){
//                    s += r.getName() + "\n";
//                    System.out.println(s);
//                }




//                System.out.println(information);

//                iv.setImageDrawable(drawable);


//                try {
//                    String imgurl = "https://i.imgur.com/mFjsApr.png";
//                    Bitmap bitmap = BitmapFactory.decodeStream((InputStream)new URL(imgurl).getContent());
//                    iv.setImageBitmap(bitmap);
//                } catch (MalformedURLException e) {
//                    e.printStackTrace();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }


//                System.out.println(information);


//                String str = obj.toString();
//                byte data[] = android.util.Base64.decode(str, Base64.DEFAULT);
//
//                Bitmap bmp = BitmapFactory.decodeByteArray(data, 0, data.length);
//                iv.setImageBitmap(bmp);


//                tv.setText(s);
//            }
//        });

        // Inflate the layout for this fragment
        return view;
    }

//    private String getStringImage(Bitmap bitmap) {
//
//        ByteArrayOutputStream baos = new ByteArrayOutputStream();
//        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
//
//        byte[] imageByte = baos.toByteArray();
//        String encodeImage = android.util.Base64.encodeToString(imageByte, Base64.DEFAULT);
//
//        return encodeImage;
//    }
}